A Microsoft Azure Three Tier Web Application Architecture For Workloads Classified as UK-OFFICIAL.
===================================================================

This architecture has moved to a new location: https://aka.ms/ukwebappblueprintrepo

