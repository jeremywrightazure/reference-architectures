﻿./format-disk DriverLetter F -DiskNumber 2
./format-disk DriverLetter G -DiskNumber 3
